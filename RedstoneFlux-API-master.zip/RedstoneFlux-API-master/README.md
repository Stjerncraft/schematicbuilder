﻿Redstone Flux API
====================================
This is the standalone CoFH Energy API - also known as the "Redstone Flux" API.

Make great use of it.

You are of course free to modify any/all of this code and even repackage it, but then it wouldn't be an awesome crossmod API anymore, now would it?

Don't be a jerk.

~Team CoFH